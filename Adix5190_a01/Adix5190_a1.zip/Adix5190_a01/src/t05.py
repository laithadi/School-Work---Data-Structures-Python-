''' 
...................................................
CP164 - Data Structures 

Author: Laith Adi 

ID: 170265190    

Email: Adix5190@mylaurier.ca

Updated: 2019-01-17 
...................................................
'''

from functions import max_diff

#defining the list 
a = [-5,5,7,11]

print(max_diff(a))

