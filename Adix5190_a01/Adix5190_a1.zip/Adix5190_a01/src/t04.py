''' 
...................................................
CP164 - Data Structures 

Author: Laith Adi 

ID: 170265190    

Email: Adix5190@mylaurier.ca

Updated: 2019-01-17 
...................................................
'''
from functions import is_leap_year

year = int(input('Enter a year: '))

print(is_leap_year(year))
