''' 
...................................................
CP164 - Data Structures 

Author: Laith Adi 

ID: 170265190    

Email: Adix5190@mylaurier.ca

Updated: 2019-02-11 
...................................................
'''

from List_array import List
l = List
key = 3
i = l._linear_search(l, key)
