''' 
...................................................
CP164 - Data Structures 

Author: Laith Adi 

ID: 170265190    

Email: Adix5190@mylaurier.ca

Updated: 2019-02-10 
...................................................
'''

from Queue_array import Queue

target = Queue()
target2 = Queue()
target2.insert(1)
target2.insert(1)
target2.insert(1)
target2.insert(1)
target2.insert(1)
target2.insert(1)
target2.insert(1)
target.insert(1)
target.insert(1)
target.insert(1)
target.insert(1)
target.insert(2)
target.insert(1)
target.insert(1)
print(target._values)
print(target2._values)



print(target2.is_identical(target))
